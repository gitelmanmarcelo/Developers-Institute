const About = () => {
    return (
        <>
        <h1>About</h1>
        <p>lorem ipLorem ipsum dolor, sit amet consectetur adipisicing elit. Eius veniam iusto voluptatem obcaecati assumenda architecto natus itaque facilis nihil. Consectetur corporis error perferendis atque voluptate provident delectus est in distinctio. </p>
        </>
    )
}

export default About;
